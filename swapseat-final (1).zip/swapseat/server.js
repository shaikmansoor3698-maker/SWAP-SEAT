const express = require('express'), crypto = require('crypto'), path = require('path');
const { db, save } = require('./lib/store');
const provider = require('./lib/providers');
const { seatType, score } = require('./lib/seats');

const app = express();
app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const uid = () => crypto.randomBytes(8).toString('hex');
const clean = (s, n = 40) => String(s || '').replace(/[<>]/g, '').trim().slice(0, n);
const wrap = fn => (q, r) => Promise.resolve(fn(q, r)).catch(e => r.status(500).json({ error: 'Server error' }));
const bad = (r, m, c = 400) => r.status(c).json({ error: m });

const auth = (q, r, next) => {
  const t = (q.headers.authorization || '').replace('Bearer ', '');
  const u = t && db.users.find(u => (u.tokens || []).includes(t));
  if (!u) return bad(r, 'Please sign in again.', 401);
  q.user = u; next();
};
const pub = t => ({ id: t.id, mode: t.mode, pnr: t.pnr, date: t.date, title: t.title, route: t.route, seat: t.seat, seatType: t.seatType, goal: t.goal, editableSeat: !!provider.editableSeat, manual: !!t.manual });
const mine = (q, r) => { const t = db.tickets.find(t => t.id === q.params.id && t.userId === q.user.id); if (!t) bad(r, 'Ticket not found.', 404); return t; };
const ownerName = t => (db.users.find(u => u.id === t.userId) || {}).name || 'Passenger';
const SEAT_RE = { train: /^[A-Z0-9]{1,3}-\d{1,3}$/, flight: /^\d{1,2}[A-K]$/ };
const PREFS = { train: ['Lower berth', 'Upper berth', 'Same coach'], flight: ['Window', 'Aisle', 'Same row'] };

// ---- auth: phone OTP ----
const otps = new Map(), hits = new Map();
const limit = (k, max, ms) => { const n = Date.now(), a = (hits.get(k) || []).filter(t => n - t < ms); a.push(n); hits.set(k, a); return a.length <= max; };
const normPhone = p => { p = String(p || '').replace(/[\s-]/g, ''); if (/^\d{10}$/.test(p)) p = '+91' + p; return /^\+[1-9]\d{9,14}$/.test(p) ? p : null; };
const hashOtp = (c, ph) => crypto.createHash('sha256').update(c + ph + (process.env.OTP_SECRET || 'dev-secret')).digest('hex');
async function sendSms(phone, text) {
  const { TWILIO_SID: sid, TWILIO_TOKEN: tok, TWILIO_FROM: from } = process.env;
  if (sid && tok && from) {
    const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, { method: 'POST', headers: { Authorization: 'Basic ' + Buffer.from(sid + ':' + tok).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ To: phone, From: from, Body: text }) });
    if (!r.ok) throw new Error('sms failed'); return false;
  }
  if (process.env.NODE_ENV === 'production') throw new Error('SMS not configured');
  console.log('[DEV OTP]', phone, text); return true; // dev: code is also returned to the browser
}
app.get('/api/config', (q, r) => r.json({ testMode: !!provider.mock, manual: !!provider.manual, flights: provider.flights !== false }));
app.post('/api/auth/otp', wrap(async (q, r) => {
  const phone = normPhone(q.body.phone); if (!phone) return bad(r, 'Enter a valid mobile number.');
  if (!limit('p' + phone, 3, 10 * 60e3) || !limit('i' + q.ip, 15, 10 * 60e3)) return bad(r, 'Too many attempts. Try again later.', 429);
  const code = String(crypto.randomInt(100000, 1000000));
  otps.set(phone, { h: hashOtp(code, phone), exp: Date.now() + 5 * 60e3, tries: 0 });
  let dev; try { dev = await sendSms(phone, `Your SwapSeat code is ${code}`); } catch { return bad(r, 'Could not send SMS.', 502); }
  r.json({ ok: true, devCode: dev ? code : undefined });
}));
app.post('/api/auth/verify', (q, r) => {
  const phone = normPhone(q.body.phone), o = phone && otps.get(phone);
  if (!o || o.exp < Date.now() || ++o.tries > 5) return bad(r, 'Code expired. Request a new one.');
  if (hashOtp(String(q.body.code || '').trim(), phone) !== o.h) return bad(r, 'Wrong code.');
  let u = db.users.find(u => u.phone === phone);
  if (!u) { const name = clean(q.body.name, 24); if (!name) return bad(r, 'New here? Enter your name.'); u = { id: uid(), phone, name, bot: false, tokens: [], createdAt: Date.now() }; db.users.push(u); }
  otps.delete(phone);
  const token = crypto.randomBytes(24).toString('hex'); u.tokens = [...(u.tokens || []), token].slice(-5); save();
  r.json({ token, user: { id: u.id, name: u.name } });
});
app.get('/api/me', auth, (q, r) => r.json({ user: { id: q.user.id, name: q.user.name }, tickets: db.tickets.filter(t => t.userId === q.user.id).map(pub), demo: process.env.DEMO === '1' }));

// ---- tickets ----
app.post('/api/verify', auth, wrap(async (q, r) => {
  const { mode } = q.body;
  const pnr = String(q.body.pnr || '').toUpperCase().replace(/\s/g, '');
  if (!PREFS[mode]) return bad(r, 'Choose train or flight.');
  if (mode === 'train' ? !/^\d{10}$/.test(pnr) : !/^[A-Z0-9]{6}$/.test(pnr)) return bad(r, mode === 'train' ? 'Enter a valid 10-digit PNR.' : 'Enter a valid 6-character booking reference.');
  if (!limit('v' + q.user.id, 20, 10 * 60e3)) return bad(r, 'Too many lookups. Try again in a few minutes.', 429);
  const date = provider.mock ? q.body.date : undefined;
  if (provider.mock && !/^\d{4}-\d{2}-\d{2}$/.test(date || '')) return bad(r, 'Choose your travel date.');
  let info;
  try { info = await provider.lookup({ mode, pnr, date }); } catch (e) { return bad(r, e.user ? e.message : 'Could not verify this PNR right now.', e.user ? 400 : 502); }
  let seat = String(q.body.seat || '').toUpperCase();
  if (info.seats.length > 1 && !seat) return r.json({ choose: info.seats, title: info.title });
  seat = seat || info.seats[0];
  if (!info.seats.includes(seat)) return bad(r, 'That seat is not on this PNR.');
  if (!provider.mock && db.tickets.some(t => t.pnr === pnr && t.seat0 === seat && t.userId !== q.user.id)) return bad(r, 'This seat is already linked to another account.', 409);
  let t = db.tickets.find(t => t.userId === q.user.id && t.pnr === pnr && t.seat0 === seat && t.date === info.date);
  if (!t) {
    const cls = mode === 'train' ? '|' + seat.split('-')[0].replace(/\d+$/, '') : '';
    t = { id: uid(), userId: q.user.id, mode, pnr, date: info.date, journeyId: info.journeyId + cls, title: info.title, route: info.route, seat, seat0: seat, seatType: seatType(mode, seat), goal: null, createdAt: Date.now() };
    db.tickets.push(t); save();
  }
  r.json({ ticket: pub(t) });
}));
app.post('/api/tickets/manual', auth, (q, r) => {
  if (!provider.manual) return bad(r, 'Use PNR verification.');
  const { mode } = q.body, date = String(q.body.date || ''), now = Date.now();
  if (!PREFS[mode]) return bad(r, 'Choose train or flight.');
  const d = new Date(date + 'T00:00:00Z');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || isNaN(d) || d < now - 1.5 * 864e5 || d > now + 125 * 864e5) return bad(r, 'Choose a travel date within the next 4 months.');
  if (!limit('m' + q.user.id, 20, 10 * 60e3)) return bad(r, 'Too many attempts. Try later.', 429);
  const no = String(q.body.no || '').toUpperCase().replace(/\s/g, ''), name = clean(q.body.name, 30);
  let seat, journeyId, title;
  if (mode === 'train') {
    const coach = String(q.body.coach || '').toUpperCase().trim(), sn = parseInt(q.body.seat, 10);
    if (!/^\d{5}$/.test(no)) return bad(r, 'Train number is 5 digits.');
    if (!/^[A-Z]{1,2}\d{1,2}$/.test(coach) || !(sn >= 1 && sn <= 120)) return bad(r, 'Enter coach like S4 and a seat/berth number (1–120).');
    seat = `${coach}-${sn}`; journeyId = `T${no}|${date}|${coach.replace(/\d+$/, '')}`; title = name ? `${no} · ${name}` : `Train ${no}`;
  } else {
    seat = String(q.body.seat || '').toUpperCase().replace(/\s/g, '');
    if (!/^[A-Z0-9]{2}\d{1,4}$/.test(no)) return bad(r, 'Flight number like 6E534.');
    if (!SEAT_RE.flight.test(seat)) return bad(r, 'Seat like 14B.');
    journeyId = `F${no}|${date}`; title = `Flight ${no}`;
  }
  const botIds = new Set(db.users.filter(u => u.bot).map(u => u.id));
  if (db.tickets.some(t => t.journeyId === journeyId && (t.seat === seat || t.seat0 === seat) && t.userId !== q.user.id && !botIds.has(t.userId))) return bad(r, 'That seat is already added by another passenger.', 409);
  let t = db.tickets.find(t => t.userId === q.user.id && t.journeyId === journeyId && t.seat0 === seat);
  if (!t) { t = { id: uid(), userId: q.user.id, mode, pnr: '', date, journeyId, title, route: '', seat, seat0: seat, seatType: seatType(mode, seat), goal: null, manual: true, createdAt: now }; db.tickets.push(t); save(); }
  r.json({ ticket: pub(t) });
});
app.get('/api/tickets/:id', auth, (q, r) => { const t = mine(q, r); if (t) r.json({ ticket: pub(t) }); });
app.put('/api/tickets/:id/seat', auth, (q, r) => {
  const t = mine(q, r); if (!t) return;
  if (!provider.editableSeat) return bad(r, 'Seat is set from your booking.', 403);
  const seat = String(q.body.seat || '').toUpperCase().replace(/\s/g, '');
  if (!SEAT_RE[t.mode].test(seat)) return bad(r, t.mode === 'train' ? 'Seat format like S4-23.' : 'Seat format like 14B.');
  t.seat = seat; t.seatType = seatType(t.mode, seat); save(); r.json({ ticket: pub(t) });
});
app.post('/api/tickets/:id/goal', auth, (q, r) => {
  const t = mine(q, r); if (!t) return;
  const pref = q.body.pref, group = Math.min(6, Math.max(2, parseInt(q.body.group, 10) || 2));
  if (!PREFS[t.mode].includes(pref)) return bad(r, 'Pick a valid preference.');
  t.goal = { pref, group, active: true }; save(); r.json({ ticket: pub(t) });
});
app.delete('/api/tickets/:id/goal', auth, (q, r) => { const t = mine(q, r); if (!t) return; if (t.goal) t.goal.active = false; save(); r.json({ ticket: pub(t) }); });

// ---- matching ----
const blocked = (a, b) => db.swaps.some(s => ['pending', 'accepted'].includes(s.status) && ((s.from === a && s.to === b) || (s.from === b && s.to === a)));
app.get('/api/tickets/:id/matches', auth, (q, r) => {
  const me = mine(q, r); if (!me) return;
  if (!me.goal || !me.goal.active) return r.json({ matches: [] });
  const matches = db.tickets
    .filter(c => c.journeyId === me.journeyId && c.userId !== me.userId && c.goal && c.goal.active && !blocked(me.id, c.id))
    .map(c => ({ ticketId: c.id, name: ownerName(c), seat: c.seat, seatType: c.seatType, wants: c.goal.pref, score: score(me, c) }))
    .sort((a, b) => b.score - a.score);
  r.json({ matches });
});

// ---- swaps ----
function resolve(s, accept) {
  if (s.status !== 'pending') return;
  const a = db.tickets.find(t => t.id === s.from), b = db.tickets.find(t => t.id === s.to);
  if (!accept || !a || !b) { s.status = 'declined'; save(); return; }
  [a.seat, b.seat] = [b.seat, a.seat];
  a.seatType = seatType(a.mode, a.seat); b.seatType = seatType(b.mode, b.seat);
  s.status = 'accepted'; s.doneAt = Date.now();
  db.swaps.filter(o => o.status === 'pending' && o !== s && [a.id, b.id].some(x => x === o.from || x === o.to)).forEach(o => o.status = 'cancelled');
  save();
}
app.post('/api/swaps', auth, (q, r) => {
  const a = db.tickets.find(t => t.id === q.body.fromTicket && t.userId === q.user.id);
  const b = db.tickets.find(t => t.id === q.body.toTicket);
  if (!a || !b || a.journeyId !== b.journeyId || a.userId === b.userId) return bad(r, 'Invalid swap.');
  if (!b.goal || !b.goal.active) return bad(r, 'That passenger is no longer swapping.');
  if (blocked(a.id, b.id)) return bad(r, 'Already requested.');
  const s = { id: uid(), from: a.id, to: b.id, status: 'pending', createdAt: Date.now() };
  db.swaps.push(s); save();
  const bot = db.users.find(u => u.id === b.userId && u.bot);
  if (bot) setTimeout(() => resolve(s, true), 2500); // demo passengers auto-accept
  r.json({ ok: true });
});
app.get('/api/swaps', auth, (q, r) => {
  const ids = new Set(db.tickets.filter(t => t.userId === q.user.id).map(t => t.id));
  const view = s => {
    const incoming = ids.has(s.to), my = db.tickets.find(t => t.id === (incoming ? s.to : s.from)), other = db.tickets.find(t => t.id === (incoming ? s.from : s.to));
    return { id: s.id, status: s.status, incoming, ticketId: my && my.id, otherName: other ? ownerName(other) : '?', otherSeat: other && other.seat, createdAt: s.createdAt };
  };
  const list = db.swaps.filter(s => ids.has(s.from) || ids.has(s.to));
  r.json({ swaps: list.map(view).filter(v => !q.query.ticket || v.ticketId === q.query.ticket).sort((a, b) => b.createdAt - a.createdAt).slice(0, 30) });
});
app.post('/api/swaps/:id/respond', auth, (q, r) => {
  const s = db.swaps.find(s => s.id === q.params.id), t = s && db.tickets.find(t => t.id === s.to && t.userId === q.user.id);
  if (!t) return bad(r, 'Request not found.', 404);
  if (s.status !== 'pending') return bad(r, 'Already ' + s.status + '.');
  resolve(s, !!q.body.accept); r.json({ ok: true, status: s.status });
});

// ---- demo passengers (so you can test alone) ----
app.post('/api/demo/seed', auth, (q, r) => {
  if (process.env.DEMO !== '1') return bad(r, 'Demo disabled.', 403);
  const me = mine({ ...q, params: { id: q.body.ticketId } }, r); if (!me) return;
  const seats = me.mode === 'train' ? ['S4-1', 'S4-8', 'S4-5', 'S4-40'] : ['14A', '14C', '15F', '16D'];
  const prefs = PREFS[me.mode], names = ['Aarav', 'Priya', 'Rohan', 'Sneha'];
  const existing = db.tickets.filter(t => t.journeyId === me.journeyId && db.users.find(u => u.id === t.userId && u.bot)).length;
  if (existing >= 4) return r.json({ ok: true });
  names.forEach((n, i) => {
    const u = { id: uid(), token: null, name: n, bot: true }; db.users.push(u);
    const seat = seats[i];
    db.tickets.push({ id: uid(), userId: u.id, mode: me.mode, pnr: 'DEMO' + i, date: me.date, journeyId: me.journeyId, title: me.title, route: me.route, seat, seatType: seatType(me.mode, seat), goal: { pref: prefs[i % 2], group: 2, active: true }, createdAt: Date.now() });
  });
  save(); r.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`SwapSeat running → http://localhost:${PORT}`));
