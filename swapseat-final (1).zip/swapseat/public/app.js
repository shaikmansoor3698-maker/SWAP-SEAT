const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const PREFS = { train: ['Lower berth', 'Upper berth', 'Same coach'], flight: ['Window', 'Aisle', 'Same row'] };
const S = { step: 1, mode: 'train', pnr: '', date: new Date().toISOString().slice(0, 10), tk: null, pref: null, group: 2, data: null, demo: false, tickets: [] };
let CFG = { testMode: false, flights: true }, phoneSt = { phone: '', sent: false, dev: '' };
let token = localStorage.getItem('ss_token'), me = null, timer = null, lastSig = '';

setTimeout(() => $('#splash').classList.add('out'), 3100);
setTimeout(() => $('#splash').remove(), 4000);

async function api(path, o = {}) {
  const r = await fetch('/api' + path, { method: o.method || 'GET', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: o.body ? JSON.stringify(o.body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401 && token) { localStorage.removeItem('ss_token'); token = null; me = null; stop(); render(); }
  if (!r.ok) throw new Error(j.error || 'Something went wrong');
  return j;
}
const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2600); };
const stop = () => { clearInterval(timer); timer = null; };

async function boot() {
  try { CFG = await (await fetch('/api/config')).json(); } catch {}
  if (!CFG.flights) S.mode = 'train';
  if (token) { try { const j = await api('/me'); me = j.user; S.demo = j.demo; S.tickets = j.tickets; } catch {} }
  render();
}
function steps() {
  $('#steps').innerHTML = me ? ['Verify', 'Set Goal', 'Swap'].map((t, i) => `<div class="${S.step == i + 1 ? 'on' : ''} ${S.step > i + 1 ? 'done' : ''}"><b>0${i + 1}</b>${t}</div>`).join('') : '';
  const w = $('#who'); w.hidden = !me; if (me) w.textContent = me.name + ' · Sign out';
}
$('#who').onclick = () => { localStorage.removeItem('ss_token'); token = null; me = null; S.step = 1; stop(); render(); };

function render() {
  steps();
  const v = $('#view');
  if (!me) {
    const P = phoneSt;
    v.innerHTML = `<div class="card"><span class="lbl">MOBILE NUMBER</span><input id="ph" inputmode="tel" value="${esc(P.phone)}" placeholder="9876543210" ${P.sent ? 'readonly' : ''}>
    ${P.sent ? `<span class="lbl">6-DIGIT CODE</span><input id="cd" inputmode="numeric" maxlength="6" placeholder="••••••" value="${esc(P.dev)}"><span class="lbl">YOUR NAME (NEW USERS)</span><input id="nm" maxlength="24" placeholder="e.g. Mansoor" style="font-family:inherit;letter-spacing:0">` : ''}
    <div class="err" id="err"></div><button class="btn" id="go">${P.sent ? 'Verify & continue' : 'Send code'}</button>${P.sent ? '<button class="ghost" id="chg">← Change number</button>' : ''}</div>`;
    const go = async () => {
      try {
        if (!P.sent) { P.phone = $('#ph').value; const j = await api('/auth/otp', { method: 'POST', body: { phone: P.phone } }); P.sent = true; P.dev = j.devCode || ''; render(); }
        else { const j = await api('/auth/verify', { method: 'POST', body: { phone: P.phone, code: $('#cd').value, name: $('#nm').value } }); token = j.token; localStorage.setItem('ss_token', token); P.sent = false; await boot(); }
      } catch (e) { $('#err').textContent = e.message; }
    };
    $('#go').onclick = go; if ($('#chg')) $('#chg').onclick = () => { P.sent = false; render(); };
    return;
  }
  if (S.step === 1) return step1(v);
  if (S.step === 2) return step2(v);
  step3(v);
}

function stepManual(v) {
  const t = S.mode === 'train', M = S.m = S.m || { no: '', name: '', coach: '', seat: '', date: S.date }, today = new Date().toISOString().slice(0, 10);
  const f = (id, l, ph, extra = '') => `<span class="lbl">${l}</span><input id="${id}" value="${esc(M[id])}" placeholder="${ph}" autocomplete="off" ${extra}>`;
  v.innerHTML = `<div class="seg"><button class="${t ? 'on' : ''}" data-m="train">🚆 TRAIN</button><button class="${!t ? 'on' : ''}" data-m="flight">✈️ FLIGHT</button></div>
  <div class="card">${t ? f('no', 'TRAIN NUMBER', '12901', 'inputmode="numeric" maxlength="5"') + f('name', 'TRAIN NAME (OPTIONAL)', 'Gujarat Mail', 'style="font-family:inherit;letter-spacing:0"') + f('coach', 'YOUR COACH', 'S4', 'maxlength="3"') + f('seat', 'SEAT / BERTH NUMBER', '23', 'inputmode="numeric" maxlength="3"') : f('no', 'FLIGHT NUMBER', '6E534', 'maxlength="7"') + f('seat', 'YOUR SEAT', '14B', 'maxlength="4"')}
  <span class="lbl">TRAVEL DATE</span><input id="date" type="date" min="${today}" value="${M.date}" style="font-family:inherit">
  <div class="err" id="err"></div><button class="btn" id="go">Add my seat</button></div>`;
  v.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { S.mode = b.dataset.m; render(); });
  const grab = () => ['no', 'name', 'coach', 'seat', 'date'].forEach(k => { const e = $('#' + k); if (e) M[k] = e.value; });
  $('#go').onclick = async () => {
    grab(); const b = $('#go'); b.disabled = true;
    try { const j = await api('/tickets/manual', { method: 'POST', body: { mode: S.mode, ...M } }); S.tk = j.ticket; S.pref = (j.ticket.goal && j.ticket.goal.pref) || PREFS[S.mode][0]; S.tickets = S.tickets.filter(k => k.id !== j.ticket.id).concat(j.ticket); S.step = 2; render(); }
    catch (e) { $('#err').textContent = e.message; b.disabled = false; }
  };
}
function step1(v) {
  if (CFG.manual) return stepManual(v);
  const t = S.mode === 'train';
  const resume = S.tickets.length ? `<div class="card"><span class="lbl">YOUR TICKETS</span>${S.tickets.slice(-3).reverse().map(k => `<div class="row" data-t="${esc(k.id)}" style="cursor:pointer"><div class="i"><b>${esc(k.title)}</b><br><small>${esc(k.date)} · seat ${esc(k.seat)}</small></div><span class="wait">Open →</span></div>`).join('')}</div>` : '';
  v.innerHTML = `<div class="seg"><button class="${t ? 'on' : ''}" data-m="train">🚆 TRAIN</button>${CFG.flights ? `<button class="${!t ? 'on' : ''}" data-m="flight">✈️ FLIGHT</button>` : '<button disabled style="opacity:.4" title="Needs airline integration">✈️ SOON</button>'}</div>${CFG.testMode ? '<p class="err" style="text-align:center">⚠ TEST MODE – simulated PNR data, not real tickets</p>' : ''}
  <div class="card"><span class="lbl">${t ? 'PNR NUMBER' : 'BOOKING REF (PNR)'}</span>
  <input id="pnr" value="${esc(S.pnr)}" inputmode="${t ? 'numeric' : 'text'}" maxlength="${t ? 10 : 6}" placeholder="${t ? '1234567890' : 'AB12CD'}" autocomplete="off">
  ${CFG.testMode ? `<span class="lbl">TRAVEL DATE</span><input id="dt" type="date" value="${S.date}" style="font-family:inherit">` : ''}
  <div class="err" id="err"></div><button class="btn" id="go">🛡️ Verify PNR</button></div>${resume}`;
  v.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { S.mode = b.dataset.m; S.pnr = ''; render(); });
  v.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { S.tk = S.tickets.find(k => k.id === b.dataset.t); S.mode = S.tk.mode; S.pref = S.tk.goal && S.tk.goal.pref; S.step = S.tk.goal && S.tk.goal.active ? 3 : 2; render(); });
  $('#pnr').oninput = e => { S.pnr = e.target.value.toUpperCase(); };
  if ($('#dt')) $('#dt').onchange = e => { S.date = e.target.value; };
  const go = async () => {
    const b = $('#go'); b.disabled = true; b.textContent = 'Verifying…';
    try { const j = await api('/verify', { method: 'POST', body: { mode: S.mode, pnr: S.pnr, date: S.date, seat: S.seatPick } }); S.seatPick = null; if (j.choose) { $('#err').innerHTML = ''; $('#go').outerHTML = `<span class="lbl">WHICH SEAT IS YOURS?</span><div class="chips" id="sp">${j.choose.map(x => `<button>${esc(x)}</button>`).join('')}</div>`; $('#sp').onclick = e => { if (e.target.tagName === 'BUTTON') { S.seatPick = e.target.textContent; render(); step1Auto(); } }; return; } S.tk = j.ticket; S.pref = (j.ticket.goal && j.ticket.goal.pref) || PREFS[S.mode][0]; S.tickets = S.tickets.filter(k => k.id !== j.ticket.id).concat(j.ticket); S.step = 2; render(); }
    catch (e) { $('#err').textContent = e.message; b.disabled = false; b.textContent = '🛡️ Verify PNR'; }
  };
  $('#go').onclick = go; $('#pnr').onkeydown = e => e.key === 'Enter' && go();
}

function step2(v) {
  const t = S.tk;
  v.innerHTML = `<div class="card"><div class="tk"><div><b>${esc(t.title)}</b><small>${esc([t.route, t.date].filter(Boolean).join(' · '))}</small>${t.pnr ? `<small>PNR ${esc(t.pnr)}</small>` : `<small>Seat ${esc(t.seat)} · ${esc(t.seatType)}</small>`}</div><span class="tag">${t.manual ? 'SELF-ADDED' : 'VERIFIED'}</span></div>
  <span class="lbl">YOUR SEAT</span>${t.editableSeat ? `<input id="seat" value="${esc(t.seat)}" maxlength="8">` : `<div class="tk"><b>${esc(t.seat)}</b><small>${esc(t.seatType)}</small></div>`}
  <span class="lbl">I WANT</span><div class="chips" id="pf">${PREFS[t.mode].map(p => `<button class="${S.pref === p ? 'on' : ''}">${p}</button>`).join('')}</div>
  <span class="lbl">TRAVELLING TOGETHER</span><div class="chips" id="gp">${[2, 3, 4, 5].map(n => `<button class="${S.group == n ? 'on' : ''}">${n} people</button>`).join('')}</div>
  <div class="err" id="err"></div><button class="btn" id="find">Find swappers</button><button class="ghost" id="back">← Change PNR</button></div>`;
  $('#pf').onclick = e => { if (e.target.tagName === 'BUTTON') { S.pref = e.target.textContent; $('#pf').querySelectorAll('button').forEach(b => b.classList.toggle('on', b === e.target)); } };
  $('#gp').onclick = e => { if (e.target.tagName === 'BUTTON') { S.group = parseInt(e.target.textContent); $('#gp').querySelectorAll('button').forEach(b => b.classList.toggle('on', b === e.target)); } };
  $('#back').onclick = () => { S.step = 1; render(); };
  $('#find').onclick = async () => {
    try {
      if (t.editableSeat && $('#seat').value.toUpperCase().replace(/\s/g, '') !== t.seat) S.tk = (await api(`/tickets/${t.id}/seat`, { method: 'PUT', body: { seat: $('#seat').value } })).ticket;
      S.tk = (await api(`/tickets/${t.id}/goal`, { method: 'POST', body: { pref: S.pref, group: S.group } })).ticket;
      S.step = 3; S.data = null; lastSig = ''; render();
    } catch (e) { $('#err').textContent = e.message; }
  };
}

async function load() {
  const [m, s, t] = await Promise.all([api(`/tickets/${S.tk.id}/matches`), api(`/swaps?ticket=${S.tk.id}`), api(`/tickets/${S.tk.id}`)]);
  if (S.tk.seat !== t.ticket.seat) toast(`Swap done! Your new seat is ${t.ticket.seat} 🎉`);
  S.tk = t.ticket; S.tickets = S.tickets.map(k => k.id === S.tk.id ? S.tk : k);
  const sig = JSON.stringify([m, s, t]);
  if (sig !== lastSig) { lastSig = sig; S.data = { matches: m.matches, swaps: s.swaps }; if (S.step === 3) render(); }
}

function step3(v) {
  if (!timer) { load().catch(() => {}); timer = setInterval(() => load().catch(() => {}), 4000); }
  if (!S.data) { v.innerHTML = `<div class="card scan"><div class="pulse"></div>Scanning co-passengers on ${esc(S.tk.title)}…</div>`; return; }
  const { matches, swaps } = S.data, inc = swaps.filter(s => s.incoming && s.status === 'pending'), out = swaps.filter(s => !s.incoming || s.status !== 'pending').slice(0, 5);
  v.innerHTML = `<div class="card"><div class="tk"><div><b>Seat ${esc(S.tk.seat)}</b><small>${esc(S.tk.seatType)} · looking for ${esc(S.tk.goal.pref)}</small></div><span class="tag">LIVE</span></div>
  ${inc.length ? `<span class="lbl">REQUESTS FOR YOU</span>${inc.map(s => `<div class="row"><div class="av">${esc(s.otherName[0])}</div><div class="i"><b>${esc(s.otherName)}</b><br><small>wants to swap with seat ${esc(s.otherSeat)}</small></div><button data-a="${s.id}">Accept</button><button class="no" data-d="${s.id}">✕</button></div>`).join('')}` : ''}
  ${out.length ? `<span class="lbl">ACTIVITY</span>${out.map(s => `<div class="row"><div class="av">${esc(s.otherName[0])}</div><div class="i"><b>${esc(s.otherName)}</b><br><small>seat ${esc(s.otherSeat)}</small></div>${s.status === 'accepted' ? '<span class="ok">Swapped ✓</span>' : s.status === 'pending' ? '<span class="wait">Waiting…</span>' : `<span class="wait">${esc(s.status)}</span>`}</div>`).join('')}` : ''}
  <span class="lbl">${matches.length ? matches.length + ' PEOPLE WILLING TO SWAP' : 'NO SWAPPERS YET'}</span>
  ${matches.map(c => `<div class="row"><div class="av">${esc(c.name[0])}</div><div class="i"><b>${esc(c.name)}</b>${c.score >= 5 ? ' ⭐' : ''}<br><small>Seat ${esc(c.seat)} · ${esc(c.seatType)}</small></div><button data-r="${c.ticketId}">Request</button></div>`).join('') || '<p class="sub" style="font-size:14px">Nobody else on this journey has set a goal yet. Ask your co-passengers to open SwapSeat — we check every few seconds.</p>'}
  ${S.demo ? '<button class="ghost" id="demo">＋ Add demo passengers (testing)</button>' : ''}<button class="ghost" id="back">← Edit goal</button></div>`;
  const act = (sel, fn) => v.querySelectorAll(sel).forEach(b => b.onclick = async () => { try { await fn(b); await load(); } catch (e) { toast(e.message); } });
  act('[data-r]', b => api('/swaps', { method: 'POST', body: { fromTicket: S.tk.id, toTicket: b.dataset.r } }).then(() => toast('Request sent')));
  act('[data-a]', b => api(`/swaps/${b.dataset.a}/respond`, { method: 'POST', body: { accept: true } }));
  act('[data-d]', b => api(`/swaps/${b.dataset.d}/respond`, { method: 'POST', body: { accept: false } }));
  act('#demo', () => api('/demo/seed', { method: 'POST', body: { ticketId: S.tk.id } }));
  $('#back').onclick = () => { stop(); S.step = 2; render(); };
}
function step1Auto() { const b = $('#go'); if (b) b.click(); }
boot();
