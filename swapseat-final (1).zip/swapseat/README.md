# SwapSeat – Sit Together. Travel Better.
Powered by FCS · Farsoor Consultancy Services

Full-stack web app: animated logo splash → Verify PNR → Set swap goal → Match & swap with co-passengers.
Node.js + Express backend, JSON-file database, vanilla JS frontend (installable as a PWA).

## Run (test mode – simulated PNRs)
    npm install && npm start      # http://localhost:3000
Login is phone OTP. Without SMS credentials the code is printed in the server console (and auto-filled in dev).

## Go LIVE with real data
Set these environment variables, then `NODE_ENV=production npm start`:
| Variable | Purpose |
|---|---|
| `RAIL_API_URL` | Your PNR-status API, with `{pnr}` placeholder, e.g. `https://example.com/pnr/{pnr}` |
| `RAIL_API_HEADERS` | JSON of auth headers, e.g. `{"X-RapidAPI-Key":"…","X-RapidAPI-Host":"…"}` |
| `TWILIO_SID` `TWILIO_TOKEN` `TWILIO_FROM` | Real SMS OTP (or edit `sendSms()` in server.js for MSG91 etc.) |
| `OTP_SECRET` | Any long random string |
| `PORT`, `DB_FILE` | Optional |
Run `curl` against your provider once and compare with `normalize()` in `lib/providers.js` – adjust the field-name lists if needed.
Live mode: only CONFIRMED seats (after chart prep) can be used; each seat can be linked to one account; swaps only between same train + date + coach class; demo passengers are off (`DEMO=1` re-enables them for testing).
Trains only: flight PNRs need an airline/GDS partnership (Amadeus/Sabre/airline API) – add it as a second branch in `real.lookup`.

## Important
The app coordinates a swap; it cannot change the railway's chart. Swap seats in person and inform the TTE/crew. Verify the PNR provider's terms before commercial use.

## API (Bearer token auth)
POST /api/auth/otp · POST /api/auth/verify · GET /api/config · GET /api/me · POST /api/verify · GET/PUT /api/tickets/:id[/seat] · POST|DELETE /api/tickets/:id/goal
GET /api/tickets/:id/matches · POST /api/swaps · GET /api/swaps · POST /api/swaps/:id/respond · POST /api/demo/seed

## Also for production
- **Real PNR verification:** implement `lib/custom-provider.js` with a licensed rail/airline data provider (IRCTC has no public PNR API), run with `PROVIDER=custom`. This also locks users from editing their seat.
- Replace the JSON store (`lib/store.js`) with Postgres/MongoDB, add real login (phone OTP), HTTPS, rate limiting, and set `DEMO=0`.
- Swap-privacy: only first name and seat are shown to others; add in-app chat/consent as needed.
